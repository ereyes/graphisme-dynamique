#!/bin/bash

adress="$*"

curl http://databaz.org/annecy/exemple_2.txt > $adress/exemple_2.txt