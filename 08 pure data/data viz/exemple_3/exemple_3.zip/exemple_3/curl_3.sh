#!/bin/bash

adress="$*"

curl http://databaz.org/annecy/exemple_3_1.txt > $adress/exemple_3_1.txt