#!/bin/bash

cd /Applications/puredata/39-GlitchAlphabetIS/japon-Kyoto/dataCityMat
cat zone_1.txt zone_1.txt zone_2.txt zone_3.txt zone_4.txt zone_5.txt zone_6.txt zone_7.txt zone_8.txt zone_9.txt zone_10.txt zone_11.txt zone_12.txt zone_13.txt zone_14.txt zone_15.txt zone_16.txt zone_17.txt zone_18.txt zone_19.txt zone_20.txt zone_21.txt zone_22.txt zone_23.txt zone_24.txt zone_25.txt zone_26.txt zone_27.txt zone_28.txt zone_29.txt zone_30.txt > union.txt

done

